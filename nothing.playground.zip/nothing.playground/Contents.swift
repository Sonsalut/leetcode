import Cocoa


//palindrome number
func isPalindrome(_ x: Int) -> Bool {
    let str = String(x)
    let reversedStr = String(str.reversed())
    if str == reversedStr {
        return true
    } else {
        return false
    }
}

//roman to integer

func romanToInt(_ s: String) -> Int {
    let romeToInt: [Character: Int] = ["I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000]
    var result = 0
    var prevValue = 0
    var reversedInput = String(s.reversed())
    
    for character in reversedInput {
        if let value = romeToInt[character] {
            if value < prevValue {
                result -= value
            } else {
                result += value
            }
            prevValue = value
        }
    }
    return result
}

//merge 2 sorted lists

class ListNode {
    var val: Int
    var next: ListNode?
    
    init(_ val: Int) {
        self.val = val
        self.next = nil
    }
}
// code copy vào để chạy
func mergeTwoLists(_ list1: ListNode?, _ list2: ListNode?) -> ListNode? {
        if list1 == nil {
            return list2
        } else if list2 == nil {
            return list1
        }


        var mergedHead: ListNode?
        var mergedTail: ListNode?

        if list1!.val < list2!.val {
            mergedHead = list1
            mergedTail = mergeTwoLists(list1!.next, list2)
        } else {
            mergedHead = list2
            mergedTail = mergeTwoLists(list1, list2!.next)
        }

        mergedHead!.next = mergedTail

        return mergedHead
    }
